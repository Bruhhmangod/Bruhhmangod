package com.terraformersmc.modmenu.gui.widget.entries;

import com.terraformersmc.modmenu.gui.widget.ModListWidget;
import com.terraformersmc.modmenu.util.mod.Mod;

public class IndependentEntry extends ModListEntry {

	public IndependentEntry(Mod mod, ModListWidget list) {
		super(mod, list);
	}
}
