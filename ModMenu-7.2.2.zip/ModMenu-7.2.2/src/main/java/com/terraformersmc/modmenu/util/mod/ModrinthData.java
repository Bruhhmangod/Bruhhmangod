package com.terraformersmc.modmenu.util.mod;

public record ModrinthData(
		String projectId,
		String versionId,
		String versionNumber
) {
}
